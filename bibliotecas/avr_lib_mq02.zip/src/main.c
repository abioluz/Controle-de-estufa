
#include <stdlib.h>
#include <string.h>
#include <math.h> //include libm
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "adc/adc.h"

#define UART_BAUD_RATE 2400
#include "uart/uart.h"

#include "dht/dht.h"

#include "mq/mq.h"

//define mq data channel
#define MQ_ADCCHANNEL 0

//define mq pulldown resistor
#define MQ_PULLDOWNRES 22000 //MQ135 pulldown resistor

//define default ppm for gas calibration
#define MQ_DEFAULTPPM 392 //MQ135 default ppm of CO2 for calibration

//define sensor resistance Ro
#define MQ_DEFAULTRO 41763 //MQ135 default Ro for CO2

//define scaling factor based on sensitivity characteristics curve
#define MQ_SCALINGFACTOR 116.6020682 //MQ135 CO2 gas value
//define exponent based on sensitivity characteristics curve
#define MQ_EXPONENT -2.769034857 //MQ135 CO2 gas value

//define max Rs/Ro interval
#define MQ_MAXRSRO 2.428 //MQ135 for CO2
//define min Rs/Ro interval
#define MQ_MINRSRO 0.358 //MQ135 for CO2

//define lookup number of points
#define MQ_LOOKUPTHSIZE 7
//define temperature lookup points
#define MQ_LOOKUPTHT {    -10,      0,     10,     20,     30,     40,     50 } //MQ135 dependance curve temperature points
//define temperature rs/ro lookup points on 1 humidity curve
#define MQ_LOOKUPTH1 { 1.7007, 1.3792, 1.1318, 0.9954, 0.9530, 0.9335, 0.9110 } //MQ135 dependance curve rs/ro over humidity 33% curve
//define temperature rs/ro lookup points on 2 humidity curve
#define MQ_LOOKUPTH2 { 1.5326, 1.2510, 1.0378, 0.9128, 0.8733, 0.8452, 0.8199 } //MQ135 dependance curve rs/ro over humidity 85% curve
//define temperature rs/ro lookup humidity 1 curve value
#define MQ_LOOKUPTH1HUMDVALUE 33 //MQ135 dependance curve humidity 33% curve
//define temperature rs/ro lookup humidity 2 curve value
#define MQ_LOOKUPTH2HUMDVALUE 85 //MQ135 dependance curve humidity 85% curve

//define reference temperature for ro as on sensitivity characteristics curve
#define MQ_SENREFTEMP 20 //MQ135 20C
//define reference humidity for ro as on sensitivity characteristics curve
#define MQ_SENREFHUMD 65 //MQ135 65%RH

int main(void) {
	char printbuff[50];
	uint16_t adc = 0;
	long ro = 0;
	double ppm = 0;
	float temperature = 0;
	float humidity = 0;

	//init uart
	uart_init( UART_BAUD_SELECT(UART_BAUD_RATE,F_CPU) );

	//init adc
	adc_init();

	//init interrupt
	sei();

	//get values
	int lookupthsize = MQ_LOOKUPTHSIZE;
	double lookuptht[] = MQ_LOOKUPTHT;
	double lookupth1[] = MQ_LOOKUPTH1;
	double lookupth2[] = MQ_LOOKUPTH2;
	double lookupth1humdvalue = MQ_LOOKUPTH1HUMDVALUE;
	double lookupth2humdvalue = MQ_LOOKUPTH2HUMDVALUE;
	int senreftemp = MQ_SENREFTEMP;
	int senrefhumd = MQ_SENREFHUMD;

	for (;;) {
		uart_puts("reading...\r\n");

		//get temperature and humidity
		if(dht_gettemperaturehumidity(&temperature, &humidity) != -1) {
			itoa((int)temperature, printbuff, 10);
			uart_puts("temp "); uart_puts(printbuff); uart_puts("\r\n");
			itoa((int)humidity, printbuff, 10);
			uart_puts("humd "); uart_puts(printbuff); uart_puts("\r\n");
		}

		//get adc
		adc = adc_read(MQ_ADCCHANNEL);
		//calculated resistence depends on the sensor pulldown resistor
		long res = adc_getresistence(adc, MQ_PULLDOWNRES);
		double adcvol = adc_getvoltage(adc, 5.0);
		//print out values
		itoa(adc, printbuff, 10);
		uart_puts("ADC "); uart_puts(printbuff); uart_puts("\r\n");
		ltoa(res, printbuff, 10);
		uart_puts("RES "); uart_puts(printbuff); uart_puts("\r\n");
		dtostrf(adcvol, 3, 3, printbuff);
		uart_puts("VOL "); uart_puts(printbuff); uart_puts("\r\n");

		//get ro
		ro = mq_getro(res, MQ_DEFAULTPPM, MQ_SCALINGFACTOR, MQ_EXPONENT);
		//get ppm using DEFAULT_RO
		ppm = mq_getppm(res, MQ_DEFAULTRO, MQ_SCALINGFACTOR, MQ_EXPONENT, MQ_MAXRSRO, MQ_MINRSRO);
		//print out values
		ltoa(ro, printbuff, 10);
		uart_puts("ro        "); uart_puts(printbuff); uart_puts("\r\n");
		dtostrf(ppm, 3, 5, printbuff);
		uart_puts("ppm_roDef "); uart_puts(printbuff); uart_puts("\r\n");

		//get ro T/H
		ro = mq_getrotemphumd(res, MQ_DEFAULTPPM, MQ_SCALINGFACTOR, MQ_EXPONENT, (int)temperature, (int)humidity, senreftemp, senrefhumd, lookupthsize, lookuptht, lookupth1, lookupth2, lookupth1humdvalue, lookupth2humdvalue);
		//get ppm using DEFAULT_ROTH
		ppm = mq_getppmtemphumd(res, MQ_DEFAULTRO, MQ_SCALINGFACTOR, MQ_EXPONENT, MQ_MAXRSRO, MQ_MINRSRO, (int)temperature, (int)humidity, senreftemp, senrefhumd, lookupthsize, lookuptht, lookupth1, lookupth2, lookupth1humdvalue, lookupth2humdvalue);
		//print out values
		ltoa(ro, printbuff, 10);
		uart_puts("roTH        "); uart_puts(printbuff); uart_puts("\r\n");
		dtostrf(ppm, 3, 5, printbuff);
		uart_puts("ppm_roTHDef "); uart_puts(printbuff); uart_puts("\r\n");

		uart_puts("\r\n");

		_delay_ms(2000);
	}
	
	return 0;
}
